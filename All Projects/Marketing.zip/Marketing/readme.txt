
===========================================================
README.TXT (c) 2013 Free Power Point Templates

===========================================================

This template was downloaded from Free Power Point Template


http://www.free-power-point-templates.com


The resource on Internet where you can download free PPT
templates for your next presentation.


 - Thank you!
   FPPT

-----------------------------------------------------------


If you liked this PPT, feel free to leave us your feedback
or testimonial sending an email
to msgs@free-power-point-templates.com or posting a comment
in our website: http://www.free-power-point-templates.com

===========================================================