/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingprincess;

import java.io.Serializable;

/**
 *
 * @author x14108682
 */
public class Details implements Serializable {

    private String name;
    private String password;
    private int age;

    public Details() {
        name = new String();
        password = new String();
        age=0;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
